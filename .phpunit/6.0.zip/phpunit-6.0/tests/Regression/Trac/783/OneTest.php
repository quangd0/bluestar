<?php
use PHPUnit\Framework\TestCase;

/**
 * @group foo
 */
class OneTest extends TestCase
{
    public function testSomething()
    {
        $this->assertTrue(true);
    }
}
